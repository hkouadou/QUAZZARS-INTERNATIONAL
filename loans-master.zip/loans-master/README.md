# loans
Loan management in odoo 10
